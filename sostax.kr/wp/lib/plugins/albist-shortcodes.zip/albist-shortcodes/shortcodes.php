<?php
/*
Plugin Name: Albist WP Shortcodes
Plugin URI: http://gomalthemes.com/
Description: Albist WP shortcodes provides a free set of different shortcodes for your wordpress theme!
Version: 1.0
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/
// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array(
        "pricing_table",
    ));
// opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}
// Container Shortcode
function container_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['class'])){
        $class = $atts['class'];
    } else {
        $class = '';
    }
    $out = '';
    $out .= '<div class="container '.$class.'">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('container', 'container_shortcode');
// Portfolio Shortcode
function portfolio_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['layout'])){
        $layout = $atts['layout'];
    } else {
        $layout = '';
    }
    if(!empty($atts['columns'])){
        $columns = $atts['columns'];
    } else {
        $columns = 'col-3';
    }
    if(!empty($atts['portfolio_categories'])){
        $portfolio_categories = $atts['portfolio_categories'];
    } else {
        $portfolio_categories = '';
    }
    if(!empty($atts['number_of_posts'])){
        $number_of_posts = $atts['number_of_posts'];
    } else {
        $number_of_posts = 6;
    }
    if(!empty($atts['load_more_page'])){
        $load_more_page = $atts['load_more_page'];
    } else {
        $load_more_page = '';
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['load_more_txt'])){
        $load_more_txt = $atts['load_more_txt'];
    } else {
        $load_more_txt = '';
    }
    if(!empty($atts['loading_txt'])){
        $loading_txt = $atts['loading_txt'];
    } else {
        $loading_txt = '';
    }
    if(!empty($atts['no_work_txt'])){
        $no_work_txt = $atts['no_work_txt'];
    } else {
        $no_work_txt = '';
    }
    if(!empty($atts['pagination'])){
        $pagination = $atts['pagination'];
    } else {
        $pagination = 'simple';
    }
    if(!empty($atts['button_txt'])){
        $button_txt = $atts['button_txt'];
    } else {
        $button_txt = '';
    }
    if(!empty($atts['button_link'])){
        $button_link = $atts['button_link'];
    } else {
        $button_link = '';
    }
    if(!empty($atts['small_caption'])){
        $small_caption = $atts['small_caption'];
    } else {
        $small_caption = '';
    }
    if(!empty($atts['hide_filters'])){
        $hide_filters = $atts['hide_filters'];
    } else {
        $hide_filters = 'show';
    }
    $portfolio_mons = '';
    if(!empty($atts['space'])){
        $space = $atts['space'];
        if($space == 'yes'){
            $portfolio_mons = 'portfolio-mons';
        }
    } else {
        $space = '';
    }
    $out = '';

    if(!empty($portfolio_categories)){
        $ex_portfolio_categories = explode(",",$portfolio_categories);
        $categories = get_terms( 'albist_genre', array(
            'orderby'    => 'count',
            'hide_empty' => 1,
            'include'    => $ex_portfolio_categories
        ) );
        // For Load More Page
        $sp_cats = $portfolio_categories;
    }else{
        $sp_cats = 'no_cat';
        $categories = get_terms( 'albist_genre', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
    }
    // Loop Arguments
    $term_array = array();
    foreach($categories as $cat) {
        $term_array[] = $cat->slug;
    }
    $portfolio = array(
        'post_type' => 'portfolio',
        'posts_per_page' => $number_of_posts,
        'order' => $order,
        'tax_query' => array(
            array(
                'taxonomy' => 'albist_genre',
                'field'    => 'slug',
                'terms'    => $term_array,
            ),
        ),
    );
    $portfolio_loop = new WP_Query($portfolio);
    // Layouts
    $class = '';
    if($layout == 'pl1'){
        $class = 'container';
    } else {
        $class = '';
    }
    $out .= '<div class="'.$class.'">';
    if($hide_filters != 'hide'){
        // Start Filter
        $out .= '<div class="text-center portfolio-filter margin-bottom-50">';
        $out .= '<div id="ajax-work-filter" class="cbp-l-filters-buttonCenter">';
        $out .= '<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">';
        $out .= esc_html__('All','albist-wp');
        $out .= '<div class="cbp-filter-counter"></div>';
        $out .= '</div>';
        foreach($categories as $cats){
            $out .= '<div data-filter=".'.esc_attr($cats->slug).'" class="cbp-filter-item">';
            $out .= esc_attr($cats->name);
            $out .= '<div class="cbp-filter-counter"></div>';
            $out .= '</div>';
        }
        $out .= '</div>';
        $out .= '</div>';
        // End Filters
    }

    $out .= '<div class="ajax-work">';
    $out .= '<div class="'.$columns.' gallery '.$portfolio_mons.'">';
    while ( $portfolio_loop->have_posts() ) : $portfolio_loop->the_post();
        $terms = get_the_terms(get_the_ID(), 'albist_genre');
        $classes = '';
        foreach ($terms as $ter){
            $classes .= esc_attr($ter->slug). ' ';
        }
        // Start Item
        $out .= '<div class="cbp-item item portfolio-item '.$classes.'">';
        $out .= '<div class="port-item">';
        if(has_post_thumbnail()){
            $out .= '<img src="'.albist_feature_image_url(get_the_ID()).'" alt="">';
        } else {
            $out .= '<img src="https://placeholdit.imgix.net/~text?txtsize=28&txt=No+Image&w=370&h=370" alt="">';
        }
        $out .= '<div class="hover-info">';
        $out .= '<div class="hover-in">';
        $out .= '<div class="position-center-center">';
        $out .= '<span>';
        $term_counter = 0;
        $len = count($terms);
        foreach ($terms as $ter){
            if ($term_counter == $len - 1) {
                $out .= esc_attr($ter->name);
            } else {
                $out .= esc_attr($ter->name). ' , ';
            }
            $term_counter++;
        }
        $out .= '</span>';
        $out .= '<hr>';
        $out .= '<h6>'.get_the_title().'</h6>';
        $portfolio_single_page_layout = albist_wp_get_field('portfolio_single_page_layout');
        if($portfolio_single_page_layout == 'popup'){
            $single = 'cbp-singlePage';
        } else {
            $single = 'singlePage';
        }
        $out .= '<a class="'.$single.'" href="'.get_the_permalink().'"><i class="lnr lnr-link"></i></a>';
        $out .= '<a href="'.albist_feature_image_url(get_the_ID()).'" class="cbp-lightbox"><i class="lnr lnr-frame-expand"></i> </a>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        // End Item
    endwhile;
    wp_reset_postdata();

    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';

    // Start Pagination
    if(!empty($load_more_txt)){
        $cl = '';
        if($layout == 'pl1'){
            $cl = 'container';
        } else {
            $class = 'container-fluid';
        }
        if($pagination == 'simple'){
            $out .= '<div class="'.$cl.'">';
            $out .= '<div class="under-port text-center">';
            $out .= '<div id="ajax-loadMore">';
            $out .= '<a href="'.esc_url(home_url('/')).'?page_id='.$load_more_page.'&number_of_posts='.$number_of_posts.'&select_portfolio_categories='.$sp_cats.'" class="cbp-l-loadMore-link btn-1" rel="nofollow">';
            $out .= '<span class="cbp-l-loadMore-defaultText">'.$load_more_txt.' <i class="fa fa-angle-down"></i></span>';
            $out .= '<span class="cbp-l-loadMore-loadingText">'.$loading_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-noMoreLoading">'.$no_work_txt.' <i class="lnr lnr-cross"></i></span>';
            $out .= '</a>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
        } else {
            $out .= '<div class="text-center under-port padding-left-50 padding-right-50">';
            $out .= '<div class="'.$class.'">';
            $out .= '<div class="row">';
            $out .= '<div class="col-sm-6">';
            if(!empty($small_caption)){
                $out .= '<h6><i class="margin-right-20 icon-pencil"></i> '.$small_caption.'</h6>';
            }
            $out .= '</div>';
            $out .= '<div class="col-sm-6 text-right">';
            $out .= '<div id="ajax-loadMore">';
            $out .= '<a href="'.esc_url(home_url('/')).'?page_id='.$load_more_page.'&number_of_posts='.$number_of_posts.'&select_portfolio_categories='.$sp_cats.'" class="cbp-l-loadMore-link btn-1" rel="nofollow">';
            $out .= '<span class="cbp-l-loadMore-defaultText">'.$load_more_txt.' <i class="fa fa-angle-down"></i></span>';
            $out .= '<span class="cbp-l-loadMore-loadingText">'.$loading_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-noMoreLoading">'.$no_work_txt.' <i class="lnr lnr-cross"></i></span>';
            $out .= '</a>';
            if(!empty($button_txt)){
                $out .= '<a href="'.$button_link.'" class="btn-1 btn-2 margin-left-30">'.$button_txt.' <i class="fa fa-plus"></i></a>';
            }
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
        }

    }
    // End Pagination
    // End Portfolio
    return $out;
}
add_shortcode('portfolio', 'portfolio_shortcode');
// Title Block Shortcode
function title_block_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['heading_above_txt'])){
        $heading_above_txt = $atts['heading_above_txt'];
    } else {
        $heading_above_txt = '';
    }
    if(!empty($atts['small_desc'])){
        $small_desc = $atts['small_desc'];
    } else {
        $small_desc = '';
    }
    if(!empty($atts['txt_alignment'])){
        $txt_alignment = $atts['txt_alignment'];
    } else {
        $txt_alignment = 'text-center';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    $out .= '<div class="heading '.$txt_alignment.' '.$style.'">';
    $out .= '<span>'.$heading_above_txt.'</span>';
    $out .= '<h4>'.$heading.'</h4>';
    $out .= '<hr>';
    $out .= '<p>'.$small_desc.'</p>';
    $out .= '</div>';
    return $out;
}
add_shortcode('title_block', 'title_block_shortcode');
// Services Box
function services_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['txt_desc'])){
        $txt_desc = $atts['txt_desc'];
    } else {
        $txt_desc = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = 'style="background: url('.$image_info[0].') no-repeat;"';
    } else {
        $image = '';
    }

    $out = '';
    if($style == 'icon-left'){
        $out .= '<div class="we-offer">';
        if(!empty($icon)){
            $out .= '<div class="media-left">';
            $out .= '<div class="icon"> <i class="'.$icon.'"></i> </div>';
            $out .= '</div>';
        }
        $out .= '<div class="media-body">';
        $out .= '<h6>'.$heading.'</h6>';
        $out .= '<hr>';
        $out .= '<p>'.$txt_desc.'</p>';
        $out .= '</div>';
        $out .= '</div>';
    } else{
        $out .= '<div class="services">';
        $out .= '<article '.$image.'>';
        $out .= '<h6>'.$heading.'</h6>';
        $out .= '<hr>';
        $out .= '<p>'.$txt_desc.'</p>';
        if(!empty($icon)){
            $out .= '<i class="'.$icon.'"></i>';
        }
        $out .= '</article>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('services_box', 'services_box_shortcode');
// Team Member Shortcode
function team_members_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img class="img-responsive" src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['name'])){
        $name = $atts['name'];
    } else {
        $name = '';
    }
    if(!empty($atts['designation'])){
        $designation = $atts['designation'];
    } else {
        $designation = '';
    }
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = $atts['linkedin'];
    } else {
        $linkedin = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }

    $out = '';
    if($style == 'side'){
        $out .= '<div class="team">';
        $out .= '<article>';
        $out .= $image;
        $out .= '<div class="team-hover">';
        $out .= '<div class="team-name">';
        $out .= '<h5>'.$name.'</h5>';
        $out .= '<span>'.$designation.'</span>';
        $out .= '</div>';
        $out .= '<ul class="social">';
        if(!empty($facebook)){
            $out .= '<li><a href="'.$facebook.'">FACEBOOK</a></li>';
        } if(!empty($twitter)){
            $out .= '<li><a href="'.$twitter.'">TWITTER</a></li>';
        } if(!empty($linkedin)){
            $out .= '<li><a href="'.$linkedin.'">LINKEDIN</a></li>';
        } if(!empty($pinterest)){
            $out .= '<li><a href="'.$pinterest.'">PINTEREST</a></li>';
        } if(!empty($instagram)){
            $out .= '<li><a href="'.$instagram.'">INSTAGRAM</a></li>';
        }
        $out .= '</ul>';
        $out .= '</div>';
        $out .= '</article>';
        $out .= '</div>';
    } else {
        $out .= '<div class="team team-style-2">';
        $out .= '<div>';
        $out .= '<article>';
        $out .= $image;
        $out .= '<div class="team-hover">';
        $out .= '<div class="team-name">';
        $out .= '<h5>'.$name.'</h5>';
        $out .= '<span>'.$designation.'</span>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</article>';
        $out .= '</div>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('team_members', 'team_members_shortcode');
// Skill bars Shortcode
function skill_bars_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = '';
    }
    if(!empty($atts['value'])){
        $value = $atts['value'];
    } else {
        $value = '';
    }
    $out = '';
    $out .= '<div class="team-skills">';
    $out .= '<div class="progress-bars style-1">';
    $out .= '<div class="bar">';
    $out .= '<p>'.$title.'</p>';
    $out .= '<div class="progress" data-percent="'.$value.'%">';
    $out .= '<div class="progress-bar">';
    $out .= '<span class="progress-bar-tooltip caret-down">'.$value.'%</span>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('skill_bars', 'skill_bars_shortcode');
// Feature Services
function feature_services_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    $out = '';
    $out .= '<div class="work-process">';
    $out .= '<div class="text-center">';
    $out .= '<article>';
    $out .= '<div class="icon">';
    $out .= '<i class="'.$icon.'"></i>';
    if(!empty($number)){
        $out .= '<span class="number">'.$number.'</span>';
    }
    $out .= '</div>';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<span>x</span>';
    $out .= '<p>'.$description.'</p>';
    $out .= '</article>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('feature_services', 'feature_services_shortcode');
// Feature List Shortcode
function feature_lists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['layout'])){
        $layout = $atts['layout'];
    } else {
        $layout = '';
    }
    $out = '';
    $out .= '<div class="feature-item '.$layout.'">';
    $out .= '<ul>';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    $out .= '</div>';
    $out .= '<div class="clearfix"></div>';
    return $out;
}
add_shortcode('feature_lists', 'feature_lists_shortcode');
add_shortcode('feature_list', 'feature_list_shortcode');
function feature_list_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    $out = '';
    $out .= '<li>';
    $out .= '<p><i class="'.$icon.'"></i> '.$heading.'</p>';
    $out .= '</li>';
    return $out;
}
// Pricing Table Shortcode
function pricing_table_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['heading_caption'])){
        $heading_caption = $atts['heading_caption'];
    } else {
        $heading_caption = '';
    }
    if(!empty($atts['currency_symbol'])){
        $currency_symbol = $atts['currency_symbol'];
    } else {
        $currency_symbol = '';
    }
    if(!empty($atts['price'])){
        $price = $atts['price'];
    } else {
        $price = '';
    }
    if(!empty($atts['period_text'])){
        $period_text = $atts['period_text'];
    } else {
        $period_text = '';
    }
    if(!empty($atts['button_text'])){
        $button_text = $atts['button_text'];
    } else {
        $button_text = '';
    }
    if(!empty($atts['button_link'])){
        $button_link = $atts['button_link'];
    } else {
        $button_link = '';
    }
    $out = '';
    $out .= '<div class="pricing">';
    $out .= '<article>';
    $out .= '<div class="price">';
    $out .= '<div class="plan-icon"> <i class="icon-pricetags"></i> </div>';
    $out .= '<h5>'.$heading.'</h5>';
    $out .= '<p class="font-lora font-italic">'.$heading_caption.'</p>';
    $out .= '</div>';
    $out .= '<div class="amount">';
    $out .= '<span class="curency">'.$currency_symbol.'</span>';
    $out .= '<span class="value">'.$price.'</span>';
    $out .= '<span class="mathod font-lora font-italic">'.$period_text.'</span>';
    $out .= '</div>';
    $out .= do_shortcode($content);
    if(!empty($button_text)){
        $out .= '<a href="'.$button_link.'" class="btn">'.$button_text.'</a>';
    }
    $out .= '</article>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pricing_table', 'pricing_table_shortcode');
// Testimonials Shortcode
function testimonials_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['grp_slug'])){
        $grp_slug = $atts['grp_slug'];
        $args = array(
            'post_type' => 'albist-testimonials',
            'posts_per_page' => $number,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'albist_testimonials_genre',
                    'field'    => 'slug',
                    'terms'    => $grp_slug,
                ),
            ),
        );
    } else {
        $args = array(
            'post_type' => 'albist-testimonials',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $out .= '<div class="testimonial">';
    $out .= '<div class="testi">';
    $out .= '<div class="two-slider">';
    $testimonials_query = new WP_Query($args);
    while($testimonials_query->have_posts()): $testimonials_query->the_post();
        $author_designation_test = albist_wp_get_field('author_designation_test');
        $author_image_test = albist_wp_get_field('author_image_test');
        $out .= '<div class="in-testi">';
        $out .= '<div class="avatars">';
        if(!empty($author_image_test)){
            $out .= '<img src="'.$author_image_test.'" alt="" >';
        }
        $out .= '</div>';
        $out .= '<div class="testi-name">';
        $out .= '<i class="fa fa-quote-left"></i>';
        $out .= '<h5>'.get_the_title().'</h5>';
        $out .= do_shortcode(get_the_content());
        $out .= '</div>';
        $out .= '<span>'.$author_designation_test.'</span>';
        $out .= '</div>';
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('testimonials', 'testimonials_shortcode');
// Blog Posts Shortcode
function blog_posts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['cat_slug'])){
        $cat_slug = $atts['cat_slug'];
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order,
            'category_name' => $cat_slug
        );
    } else {
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $blog_query = new WP_Query($args);
    $out .= '<div class="blog">';
    $out .= '<div class="row">';
    $count = 1;
    while($blog_query->have_posts()): $blog_query->the_post();
        $out .= '<div class="col-md-4">';
        $out .= '<article>';
        if(has_post_thumbnail()){
            $out .= '<img class="img-responsive" src="'.albist_feature_image_url(get_the_ID()).'" alt="" >';
        }
        $out .= '<div class="post-info">';
        $out .= '<div class="post-in">';
        $out .= '<div class="extra">';
        $out .= '<span><i class="icon-calendar"></i>'.get_the_time('M j, Y').'</span>';
        $out .= '<span class="margin-left-15"><i class="icon-user"></i>'.get_the_author().'</span>';
        $cats = get_the_category(get_the_ID());
        $out .= '<span class="margin-left-15"><i class="icon-bubbles"></i>';
        $post_count = 0;
        $len = count($cats);
        foreach($cats as $cat){
            if ($post_count == $len - 1) {
                $out .= $cat->cat_name;
            } else {
                $out .= $cat->cat_name. ', ';
            }
            $post_count++;
        }
        $out .= '</span>';
        $out .= '</div>';
        $out .= '<a href="'.get_the_permalink().'" class="tittle-post">'.get_the_title().'</a>';
        $out .= '<a href="'.get_the_permalink().'" class="btn-1">'.esc_html__('Read More','albist-wp').' <i class="fa fa-angle-right"></i></a>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</article>';
        $out .= '</div>';
        if($count % 3 == 0){
            $out .= '<div class="clear clearfix"></div>';
        }
        $count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('blog_posts', 'blog_posts_shortcode');
// Plain Tabs Shortcode
function plain_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['tab_headings'])){
        $tab_headings = rawurldecode(base64_decode(strip_tags($atts['tab_headings'])));
    } else {
        $tab_headings = '';
    }
    if(!empty($atts['position'])){
        $position = $atts['position'];
    } else {
        $position = '';
    }
    $out = '';
    $out .= ' <div class="story">';
    if($position == 'bottom'){
        $out .= ' <div class="tab-content">';
        $out .= do_shortcode($content);
        $out .= '</div>';
    }
    $out .= '<ul class="tabs" role="tablist">';
    $ex_tab_headings = explode('++',$tab_headings);
    $heading_count = 1;
    foreach ($ex_tab_headings as $heading) {
        if($heading_count == 1){
            $active = 'class="active"';
        } else {
            $active = '';
        }
        $out .= '<li role="presentation" '.$active.'><a href="#tab-'. $heading_count .'" role="tab" data-toggle="tab" aria-controls="tab-'. $heading_count .'">' . $heading . '</a></li>';
        $heading_count++;
    }
    $out .= '</ul>';
    if($position == 'top'){
        $out .= ' <div class="tab-content">';
        $out .= do_shortcode($content);
        $out .= '</div>';
    }
    $out .= '</div>';
    return $out;
}
add_shortcode('plain_tabs', 'plain_tabs_shortcode');
add_shortcode('plain_tab', 'plain_tab_shortcode');
function plain_tab_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    STATIC $id = 0;
    $id++;
    if($id == 1){
        $class = 'in active';
    } else {
        $class = '';
    }
    $out .= '<div role="tabpanel" class="tab-pane fade '.$class.'" id="tab-' . $id . '">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
// Feature Checklist Shortcode
function feature_checklists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    $out = '';
    $out .= '<div class="build-feature">';
    $out .= '<div class="feature-list-check">';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<ul class="margin-top-20">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('feature_checklists', 'feature_checklists_shortcode');
add_shortcode('feature_checklist', 'feature_checklist_shortcode');
function feature_checklist_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['txt'])){
        $txt = $atts['txt'];
    } else {
        $txt = '';
    }
    $out = '';
    $out .= '<li>'.$txt.'</li>';
    return $out;
}
// Facts & Figures
function facts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    $out = '';
    $out .= '<div class="facts margin-bottom-30">';
    $out .= '<div class="fats-conter">';
    $out .= '<span class="number"> <span class="timer" data-speed="2000" data-refresh-interval="100" data-to="'.$number.'" data-from="0">'.$number.' <i class="'.$icon.'"></i></span> </span>';
    $out .= '<h5>'.$heading.'</h5>';
    $out .= '<hr>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('facts', 'facts_shortcode');
// Toggle Services Box
function toggle_services_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = 'style="background: url('.$image_info[0].') no-repeat;"';
    } else {
        $image = '';
    }
    if(!empty($atts['side_image'])){
        $image_info = wp_get_attachment_image_src( $atts['side_image'], 'full' );
        $side_image = '<img src="'.$image_info[0].'" alt="" >';
    } else {
        $side_image = '';
    }
    if(!empty($atts['position'])){
        $position = $atts['position'];
    } else {
        $position = 'right';
    }

    $random = rand(10,99999);

    $out = '';
    $out .= '<div class="services best-services">';
    $out .= '<div class="list">';
    $out .= '<div data-content="#colio_'.$random.'">';
    $out .= '<article '.$image.'>';
    $out .= '<i class="'.$icon.'"></i>';
    $out .= '<hr>';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<a class="colio-link btn-1" href="#" >'.esc_html__('READ MORE','albist-wp').'<i class="lnr lnr-chevron-down"></i></a>';
    $out .= '</article>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    // Toggle
    $out .= '<div id="colio_'.$random.'" class="colio-content">';
    $out .= '<div class="main">';
    $out .= '<div class="inside-colio">';
    $out .= '<i class="icon-big '.$icon.'"></i>';
    $out .= '<div class="container">';
    $out .= '<div class="row">';
    if($position == 'left'){
        $out .= '<div class="col-md-5"> '.$side_image.' </div>';
    }
    $out .= '<div class="col-md-7">';
    $out .= '<h4>'.$heading.'</h4>';
    $out .= '<hr>';
    $out .= '<div class="feature-list-check margin-top-10">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    if($position == 'right'){
        $out .= '<div class="col-md-5"> '.$side_image.' </div>';
    }
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('toggle_services_box', 'toggle_services_box_shortcode');
// Simple Image Shortcode
function simple_img_slides_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div  class="single-slide story">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('simple_img_slides', 'simple_img_slides_shortcode');
add_shortcode('simple_img_slide', 'simple_img_slide_shortcode');
function simple_img_slide_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img class="img-responsive" src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    $out = '';
    $out .= '<div>';
    $out .= $image;
    $out .= '</div>';
    return $out;
}
// Text Widget Shortcode Readable
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');