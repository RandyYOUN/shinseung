<?php

/**
 * Implement this interface to state that the field control is Multi Selectable
 */
interface VP_MultiSelectable{}

/**
 * EOF
 */