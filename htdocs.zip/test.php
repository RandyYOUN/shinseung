<?php
	$test1 = 1;
	$test2 = 2;

	if($test1 = 1){
		echo 'test1 + test2 = '.$test1.$test2;
	}

	
?>
