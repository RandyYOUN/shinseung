<?php 

echo '1';


echo '2';
//phpinfo(); 


?>

